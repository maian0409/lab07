using System.ComponentModel.DataAnnotations;

namespace lab07.Models;

public class Product
{
    public int Id { get; set; }

    [Display(Name = "Tên sản phẩm")]
    [Required(ErrorMessage = "Tên sản phẩm không được để trống")]
    [StringLength(150, MinimumLength = 6, ErrorMessage = "Tên sản phẩm phải từ 6 đến 150 ký tự")]
    public string Name { get; set; } = string.Empty;

    [Display(Name = "Hình ảnh")]
    public string Image { get; set; } = string.Empty;

    [Display(Name = "Giá")]
    [Required(ErrorMessage = "Giá sản phẩm không được để trống")]
    [Range(100000, float.MaxValue, ErrorMessage = "Giá sản phẩm phải lớn hơn hoặc bằng 100000")]
    public float Price { get; set; }

    [Display(Name = "Giá khuyến mãi")]
    [Required(ErrorMessage = "Giá khuyến mãi không được để trống")]
    [Range(0, float.MaxValue, ErrorMessage = "Giá khuyến mãi không được âm")]
    public float SalePrice { get; set; }

    [Display(Name = "Mô tả")]
    [Required(ErrorMessage = "Mô tả không được để trống")]
    [StringLength(1500, ErrorMessage = "Mô tả không được vượt quá 1500 ký tự")]
    public string Description { get; set; } = string.Empty;

    [Display(Name = "Danh mục")]
    [Required(ErrorMessage = "Vui lòng chọn danh mục")]
    public int CategoryId { get; set; }
}
