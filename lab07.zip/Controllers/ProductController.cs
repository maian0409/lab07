using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using lab07.Models;

namespace lab07.Controllers;

public class ProductController : Controller
{
    private static readonly List<Product> Products = new();

    private static readonly List<Category> Categories =
    [
        new Category { Id = 1, Name = "Điện thoại" },
        new Category { Id = 2, Name = "Laptop" },
        new Category { Id = 3, Name = "Phụ kiện" }
    ];

    public IActionResult Index()
    {
        ViewBag.Categories = Categories;
        return View(Products);
    }

    public IActionResult Details(int id)
    {
        var product = Products.FirstOrDefault(x => x.Id == id);

        if (product == null)
            return NotFound();

        ViewBag.CategoryName = Categories
            .FirstOrDefault(x => x.Id == product.CategoryId)?.Name ?? "Không xác định";

        return View(product);
    }

    public IActionResult Create()
    {
        SetCategories();
        return View(new Product());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Product product, IFormFile? imageFile)
    {
        ValidateSalePrice(product);

        if (imageFile == null || imageFile.Length == 0)
            ModelState.AddModelError("Image", "Vui lòng chọn hình ảnh sản phẩm");
        else if (!IsImage(imageFile))
            ModelState.AddModelError("Image", "Vui lòng chọn file ảnh hợp lệ");

        if (ModelState.IsValid)
        {
            product.Id = Products.Count == 0 ? 1 : Products.Max(x => x.Id) + 1;
            product.Image = SaveImage(imageFile!);
            Products.Add(product);

            return RedirectToAction(nameof(Index));
        }

        SetCategories(product.CategoryId);
        return View(product);
    }

    public IActionResult Edit(int id)
    {
        var product = Products.FirstOrDefault(x => x.Id == id);

        if (product == null)
            return NotFound();

        SetCategories(product.CategoryId);
        return View(product);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(Product product, IFormFile? imageFile)
    {
        var oldProduct = Products.FirstOrDefault(x => x.Id == product.Id);

        if (oldProduct == null)
            return NotFound();

        ValidateSalePrice(product);

        if (ModelState.IsValid)
        {
            oldProduct.Name = product.Name;
            oldProduct.Price = product.Price;
            oldProduct.SalePrice = product.SalePrice;
            oldProduct.Description = product.Description;
            oldProduct.CategoryId = product.CategoryId;

            if (imageFile != null && imageFile.Length > 0)
            {
                if (!IsImage(imageFile))
                {
                    ModelState.AddModelError("Image", "Vui lòng chọn file ảnh hợp lệ");
                    SetCategories(product.CategoryId);
                    return View(product);
                }

                oldProduct.Image = SaveImage(imageFile);
            }

            return RedirectToAction(nameof(Index));
        }

        SetCategories(product.CategoryId);
        return View(product);
    }

    public IActionResult Delete(int id)
    {
        var product = Products.FirstOrDefault(x => x.Id == id);

        if (product == null)
            return NotFound();

        return View(product);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public IActionResult DeleteConfirmed(int id)
    {
        var product = Products.FirstOrDefault(x => x.Id == id);

        if (product != null)
            Products.Remove(product);

        return RedirectToAction(nameof(Index));
    }

    private void SetCategories(int? selectedId = null)
    {
        ViewBag.CategoryId = new SelectList(Categories, "Id", "Name", selectedId);
    }

    private void ValidateSalePrice(Product product)
    {
        if (product.SalePrice > product.Price * 0.9f)
        {
            ModelState.AddModelError(
                "SalePrice",
                "Giá khuyến mãi phải nhỏ hơn hoặc bằng 90% giá chuẩn");
        }
    }

    private static bool IsImage(IFormFile file)
    {
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        return extension is ".jpg" or ".jpeg" or ".png" or ".gif" or ".webp";
    }

    private static string SaveImage(IFormFile file)
    {
        var folder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "products");

        if (!Directory.Exists(folder))
            Directory.CreateDirectory(folder);

        var fileName = Guid.NewGuid() + Path.GetExtension(file.FileName);
        var filePath = Path.Combine(folder, fileName);

        using var stream = new FileStream(filePath, FileMode.Create);
        file.CopyTo(stream);

        return fileName;
    }
}
