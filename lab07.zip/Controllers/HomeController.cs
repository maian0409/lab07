using Microsoft.AspNetCore.Mvc;

namespace lab07.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return RedirectToAction("Index", "Product");
    }
}
